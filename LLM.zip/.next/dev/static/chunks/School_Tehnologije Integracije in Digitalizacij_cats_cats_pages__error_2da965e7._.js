(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/f13b8_next_dist_compiled_9e2cc3c2._.js",
  "static/chunks/f13b8_next_dist_shared_lib_cfb2e476._.js",
  "static/chunks/f13b8_next_dist_client_3793e4d5._.js",
  "static/chunks/f13b8_next_dist_ac6d8565._.js",
  "static/chunks/f13b8_next_error_a1577e30.js",
  "static/chunks/[next]_entry_page-loader_ts_501a09c6._.js",
  "static/chunks/f13b8_react-dom_f63ac714._.js",
  "static/chunks/f13b8_a850c8ef._.js",
  "static/chunks/[root-of-the-server]__5677a870._.js"
],
    source: "entry"
});
