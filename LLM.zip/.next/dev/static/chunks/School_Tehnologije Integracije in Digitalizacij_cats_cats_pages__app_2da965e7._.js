(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/f13b8_next_dist_compiled_9e2cc3c2._.js",
  "static/chunks/f13b8_next_dist_shared_lib_78027dbc._.js",
  "static/chunks/f13b8_next_dist_client_3793e4d5._.js",
  "static/chunks/f13b8_next_dist_764e85ce._.js",
  "static/chunks/f13b8_next_app_655eb53d.js",
  "static/chunks/[next]_entry_page-loader_ts_d4a3072e._.js",
  "static/chunks/f13b8_react-dom_f63ac714._.js",
  "static/chunks/f13b8_a850c8ef._.js",
  "static/chunks/[root-of-the-server]__e0f9522d._.js"
],
    source: "entry"
});
