(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_9d665b75._.js",
  "static/chunks/f13b8_next_dist_compiled_react-dom_224da474._.js",
  "static/chunks/f13b8_next_dist_compiled_react-server-dom-turbopack_c90b52af._.js",
  "static/chunks/f13b8_next_dist_compiled_next-devtools_index_37d188a4.js",
  "static/chunks/f13b8_next_dist_compiled_5847bf7c._.js",
  "static/chunks/f13b8_next_dist_client_1b72f04e._.js",
  "static/chunks/f13b8_next_dist_3a47afdd._.js",
  "static/chunks/f13b8_@swc_helpers_cjs_1b473e14._.js"
],
    source: "entry"
});
