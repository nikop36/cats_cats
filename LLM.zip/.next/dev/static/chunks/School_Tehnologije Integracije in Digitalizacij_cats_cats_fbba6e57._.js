(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/llm/ActivitySuggestion.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ActivitySuggestion
]);
class ActivitySuggestion {
    title;
    description;
    time;
    tags;
    constructor({ title, description, time, tags }){
        this.title = title || "Untitled activity";
        this.description = description || "";
        this.time = time || "";
        this.tags = Array.isArray(tags) ? tags : [];
    }
    static fromJSON(obj) {
        if (!obj || typeof obj !== "object") throw new Error("Invalid suggestion object");
        return new ActivitySuggestion({
            title: String(obj.title || ""),
            description: String(obj.description || ""),
            time: String(obj.time || ""),
            tags: Array.isArray(obj.tags) ? obj.tags.map(String) : []
        });
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Home
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$app$2f$llm$2f$ActivitySuggestion$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/llm/ActivitySuggestion.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function Home() {
    _s();
    const [cats, setCats] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [streaming, setStreaming] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [streamType, setStreamType] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("feed");
    const [breedFilter, setBreedFilter] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [streamStatus, setStreamStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [messageCount, setMessageCount] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const eventSourceRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const messageCountRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    // Fetch initial cats
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Home.useEffect": ()=>{
            let mounted = true;
            setLoading(true);
            fetch("/api/cats").then({
                "Home.useEffect": (res)=>{
                    if (!res.ok) throw new Error(`HTTP ${res.status}`);
                    return res.json();
                }
            }["Home.useEffect"]).then({
                "Home.useEffect": (data)=>{
                    if (!mounted) return;
                    setCats(Array.isArray(data.cats) ? data.cats : []);
                    setError(null);
                }
            }["Home.useEffect"]).catch({
                "Home.useEffect": (err)=>{
                    if (!mounted) return;
                    console.error("[Frontend] Initial fetch error:", err);
                    setError(err.message || "Failed to fetch");
                    setCats([]);
                }
            }["Home.useEffect"]).finally({
                "Home.useEffect": ()=>{
                    if (!mounted) return;
                    setLoading(false);
                }
            }["Home.useEffect"]);
            return ({
                "Home.useEffect": ()=>{
                    mounted = false;
                }
            })["Home.useEffect"];
        }
    }["Home.useEffect"], []);
    // Handle streaming
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Home.useEffect": ()=>{
            // If breed stream is selected but no breed entered, don't start streaming
            if (streaming && streamType === "breed" && !breedFilter.trim()) {
                console.log("[Frontend] Breed filter empty, not starting stream");
                setStreamStatus("⏳ Enter a breed name to start streaming");
                return;
            }
            if (!streaming) {
                if (eventSourceRef.current) {
                    console.log("[Frontend] Closing stream");
                    eventSourceRef.current.close();
                    eventSourceRef.current = null;
                }
                setStreamStatus("");
                messageCountRef.current = 0;
                setMessageCount(0);
                return;
            }
            let mounted = true;
            // Build URL
            const url = new URL("/api/cats/stream", window.location.origin);
            url.searchParams.set("type", streamType);
            if (streamType === "breed") {
                url.searchParams.set("breed", breedFilter.trim());
            }
            const streamUrl = url.toString();
            console.log(`[Frontend] Opening stream: ${streamUrl}`);
            setStreamStatus(`🔄 Connecting to ${streamType}... `);
            messageCountRef.current = 0;
            setMessageCount(0);
            try {
                const es = new EventSource(streamUrl);
                eventSourceRef.current = es;
                es.addEventListener("message", {
                    "Home.useEffect": (event)=>{
                        if (!mounted) return;
                        try {
                            const data = JSON.parse(event.data);
                            console.log(`[Frontend] Received:`, data);
                            if (data.error) {
                                console.error("[Frontend] Server error:", data.error);
                                setError(`Stream error: ${data.error}`);
                                setStreaming(false);
                                return;
                            }
                            // Extract cat from message
                            const cat = data.cat || data;
                            if (!cat.id) {
                                console.warn("[Frontend] Invalid cat data:", data);
                                return;
                            }
                            console.log(`[Frontend] Got cat: ${cat.breed}`);
                            setCats({
                                "Home.useEffect": (prevCats)=>{
                                    const exists = prevCats.some({
                                        "Home.useEffect.exists": (c)=>c.id === cat.id
                                    }["Home.useEffect.exists"]);
                                    if (exists) {
                                        console.log(`[Frontend] Cat already exists: ${cat.id}`);
                                        return prevCats;
                                    }
                                    return [
                                        cat,
                                        ...prevCats
                                    ];
                                }
                            }["Home.useEffect"]);
                            messageCountRef.current++;
                            setMessageCount(messageCountRef.current);
                            setStreamStatus(`✅ Streaming ${streamType}${streamType === "breed" ? ` (${breedFilter})` : ""} - ${messageCountRef.current} messages`);
                        } catch (err) {
                            console.error("[Frontend] Parse error:", err, "Raw data:", event.data);
                        }
                    }
                }["Home.useEffect"]);
                es.onerror = ({
                    "Home.useEffect": (event)=>{
                        console.error("[Frontend] EventSource onerror.  ReadyState:", es.readyState, "Event:", event);
                        if (mounted) {
                            // ReadyState: 0=connecting, 1=open, 2=closed
                            if (es.readyState === EventSource.CLOSED) {
                                console.log("[Frontend] Stream closed by server");
                                setStreamStatus("⏹️ Stream closed (server ended)");
                            } else {
                                console.error("[Frontend] Stream connection lost");
                                setError(`Stream connection lost (readyState: ${es.readyState})`);
                                setStreaming(false);
                            }
                        }
                        es.close();
                    }
                })["Home.useEffect"];
                console.log("[Frontend] Stream opened successfully");
            } catch (err) {
                console.error("[Frontend] Stream setup error:", err);
                if (mounted) {
                    setError(`Stream error: ${String(err)}`);
                    setStreaming(false);
                }
            }
            return ({
                "Home.useEffect": ()=>{
                    mounted = false;
                    if (eventSourceRef.current) {
                        console.log("[Frontend] Cleanup: closing stream");
                        eventSourceRef.current.close();
                        eventSourceRef.current = null;
                    }
                }
            })["Home.useEffect"];
        }
    }["Home.useEffect"], [
        streaming,
        streamType,
        breedFilter
    ]);
    // LLM form state
    const [llmDate, setLlmDate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "Home.useState": ()=>new Date().toISOString().slice(0, 10)
    }["Home.useState"]);
    const [llmLocation, setLlmLocation] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [llmCount, setLlmCount] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(3);
    const [llmBreed, setLlmBreed] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [suggestions, setSuggestions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [llmLoading, setLlmLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null); // <-- added
    async function callLLM() {
        setError(null);
        setLlmLoading(true);
        setSuggestions([]);
        try {
            const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
            const userAgent = navigator.userAgent;
            const res = await fetch("/api/llm", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    date: llmDate,
                    location: llmLocation || "Unknown location",
                    count: llmCount,
                    breed: llmBreed.trim() || undefined,
                    timezone,
                    userAgent
                })
            });
            if (!res.ok) {
                let errBody;
                try {
                    errBody = await res.json();
                } catch  {
                    try {
                        errBody = await res.text();
                    } catch  {
                        errBody = `HTTP ${res.status} ${res.statusText}`;
                    }
                }
                const msg = errBody && typeof errBody === "object" ? errBody.error || errBody.message || JSON.stringify(errBody) : String(errBody);
                console.warn("[LLM] server error:", res.status, msg);
                throw new Error(msg || `HTTP ${res.status}`);
            }
            const data = await res.json();
            console.debug("[LLM] response", data);
            const rawSuggestions = Array.isArray(data.suggestions) ? data.suggestions : [];
            const parsed = rawSuggestions.map((s)=>__TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$app$2f$llm$2f$ActivitySuggestion$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].fromJSON(s));
            setSuggestions(parsed);
        } catch (e) {
            console.error("[LLM] Error:", e);
            setError(e?.message || "LLM request failed");
        } finally{
            setLlmLoading(false);
        }
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        style: {
            padding: "20px",
            fontFamily: "sans-serif"
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                children: "🐱 Cat Feed with gRPC Streaming"
            }, void 0, false, {
                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                lineNumber: 263,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    marginBottom: "20px",
                    padding: "15px",
                    backgroundColor: "gray",
                    borderRadius: "8px"
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            marginBottom: "10px"
                        },
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "checkbox",
                                    checked: streaming,
                                    onChange: (e)=>{
                                        setStreaming(e.target.checked);
                                        if (!e.target.checked) {
                                            setStreamType("feed");
                                            setBreedFilter("");
                                        }
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                    lineNumber: 274,
                                    columnNumber: 13
                                }, this),
                                " Enable Real-time Streaming"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                            lineNumber: 273,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                        lineNumber: 272,
                        columnNumber: 9
                    }, this),
                    streaming && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    marginBottom: "10px"
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        children: "Stream Type: "
                                    }, void 0, false, {
                                        fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                        lineNumber: 292,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                        value: streamType,
                                        onChange: (e)=>{
                                            setStreamType(e.target.value);
                                            if (e.target.value !== "breed") {
                                                setBreedFilter("");
                                            }
                                        },
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "feed",
                                                children: "📡 StreamCatFeed (All)"
                                            }, void 0, false, {
                                                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                                lineNumber: 302,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "new",
                                                children: "🆕 StreamNewCats (New Only)"
                                            }, void 0, false, {
                                                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                                lineNumber: 303,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "breed",
                                                children: "🐱 StreamCatsByBreed (Filter)"
                                            }, void 0, false, {
                                                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                                lineNumber: 304,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                        lineNumber: 293,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                lineNumber: 291,
                                columnNumber: 13
                            }, this),
                            streamType === "breed" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        children: "Breed Filter: "
                                    }, void 0, false, {
                                        fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                        lineNumber: 310,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "text",
                                        placeholder: "e.g., Tabby, Siamese, Maine",
                                        value: breedFilter,
                                        onChange: (e)=>setBreedFilter(e.target.value),
                                        style: {
                                            padding: "5px",
                                            marginLeft: "10px"
                                        },
                                        autoFocus: true
                                    }, void 0, false, {
                                        fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                        lineNumber: 311,
                                        columnNumber: 17
                                    }, this),
                                    breedFilter && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                                        style: {
                                            marginLeft: "10px",
                                            color: "#666"
                                        },
                                        children: [
                                            '✅ Filter active: "',
                                            breedFilter,
                                            '"'
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                        lineNumber: 320,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                lineNumber: 309,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true)
                ]
            }, void 0, true, {
                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                lineNumber: 264,
                columnNumber: 7
            }, this),
            loading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: "⏳ Loading..."
            }, void 0, false, {
                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                lineNumber: 331,
                columnNumber: 19
            }, this),
            streamStatus && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    color: streamStatus.includes("⏳") ? "orange" : streamStatus.includes("❌") ? "red" : "green",
                    marginBottom: "10px",
                    padding: "10px",
                    backgroundColor: "gray",
                    borderRadius: "4px"
                },
                children: streamStatus
            }, void 0, false, {
                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                lineNumber: 333,
                columnNumber: 9
            }, this),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    color: "red",
                    marginBottom: "10px",
                    padding: "10px",
                    backgroundColor: "gray",
                    borderRadius: "4px"
                },
                children: [
                    "❌ ",
                    error
                ]
            }, void 0, true, {
                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                lineNumber: 350,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                style: {
                    margin: 16,
                    padding: 12,
                    background: "gray",
                    borderRadius: 8
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        children: "🤖 Dynamic LLM Activity Suggestions"
                    }, void 0, false, {
                        fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                        lineNumber: 371,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        style: {
                            fontSize: 12,
                            color: "#ccc",
                            marginBottom: 12
                        },
                        children: "Get personalized cat-related activity suggestions based on your location, date, and device context. Optionally specify a cat breed to get fun facts included!"
                    }, void 0, false, {
                        fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                        lineNumber: 372,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            display: "flex",
                            gap: 8,
                            alignItems: "center",
                            marginBottom: 8
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                children: [
                                    "Date:",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "date",
                                        value: llmDate,
                                        onChange: (e)=>setLlmDate(e.target.value),
                                        style: {
                                            marginLeft: 8
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                        lineNumber: 387,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                lineNumber: 385,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                children: [
                                    "Location:",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "text",
                                        value: llmLocation,
                                        onChange: (e)=>setLlmLocation(e.target.value),
                                        placeholder: "e.g., Ljubljana, New York",
                                        style: {
                                            marginLeft: 8,
                                            minWidth: 180
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                        lineNumber: 396,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                lineNumber: 394,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                children: [
                                    "Cat Breed (optional):",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "text",
                                        value: llmBreed,
                                        onChange: (e)=>setLlmBreed(e.target.value),
                                        placeholder: "e.g., Persian, Siamese",
                                        style: {
                                            marginLeft: 8,
                                            minWidth: 150
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                        lineNumber: 406,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                lineNumber: 404,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                children: [
                                    "Count:",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "number",
                                        min: 1,
                                        max: 10,
                                        value: llmCount,
                                        onChange: (e)=>setLlmCount(Number(e.target.value)),
                                        style: {
                                            width: 64,
                                            marginLeft: 8
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                        lineNumber: 416,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                lineNumber: 414,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: callLLM,
                                disabled: llmLoading,
                                style: {
                                    marginLeft: 8,
                                    cursor: llmLoading ? "wait" : "pointer"
                                },
                                children: llmLoading ? "🔄 Generating..." : "✨ Get Suggestions"
                            }, void 0, false, {
                                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                lineNumber: 425,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                        lineNumber: 377,
                        columnNumber: 9
                    }, this),
                    error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            color: "crimson",
                            marginBottom: 8,
                            padding: 8,
                            background: "#ffe0e0",
                            borderRadius: 4
                        },
                        children: [
                            "❌ Error: ",
                            error
                        ]
                    }, void 0, true, {
                        fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                        lineNumber: 435,
                        columnNumber: 11
                    }, this),
                    suggestions.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            marginTop: 12
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                children: [
                                    "📋 Suggestions for ",
                                    llmLocation || "your area",
                                    " on ",
                                    llmDate
                                ]
                            }, void 0, true, {
                                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                lineNumber: 450,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                style: {
                                    paddingLeft: 20
                                },
                                children: suggestions.map((s, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        style: {
                                            marginBottom: 12
                                        },
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                style: {
                                                    color: "#4a9eff"
                                                },
                                                children: s.title
                                            }, void 0, false, {
                                                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                                lineNumber: 456,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                style: {
                                                    marginLeft: 8,
                                                    fontSize: 12,
                                                    color: "#999"
                                                },
                                                children: [
                                                    "⏰ ",
                                                    s.time
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                                lineNumber: 457,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                style: {
                                                    marginTop: 4
                                                },
                                                children: s.description
                                            }, void 0, false, {
                                                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                                lineNumber: 460,
                                                columnNumber: 19
                                            }, this),
                                            s.tags.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                style: {
                                                    fontSize: 11,
                                                    color: "#aaa",
                                                    marginTop: 4
                                                },
                                                children: [
                                                    "🏷️ ",
                                                    s.tags.map((tag)=>`#${tag}`).join(" ")
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                                lineNumber: 462,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, i, true, {
                                        fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                        lineNumber: 455,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                lineNumber: 453,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                        lineNumber: 449,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                lineNumber: 363,
                columnNumber: 7
            }, this),
            !loading && cats.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        children: [
                            cats.length,
                            " Cats ",
                            streamType === "breed" && `(${breedFilter})`
                        ]
                    }, void 0, true, {
                        fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                        lineNumber: 476,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            display: "grid",
                            gridTemplateColumns: "repeat(auto-fill, minmax(250px, 1fr))",
                            gap: "20px"
                        },
                        children: cats.map((c)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    border: "1px solid #ddd",
                                    borderRadius: "8px",
                                    padding: "12px",
                                    boxShadow: "0 2px 4px rgba(0,0,0,0.1)"
                                },
                                children: [
                                    c.url && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                        src: c.url,
                                        alt: c.breed,
                                        width: "100%",
                                        style: {
                                            height: "200px",
                                            objectFit: "cover",
                                            borderRadius: "4px",
                                            marginBottom: "8px"
                                        },
                                        onError: (e)=>{
                                            e.target.style.display = "none";
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                        lineNumber: 497,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        style: {
                                            fontSize: "14px"
                                        },
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                style: {
                                                    fontWeight: "bold",
                                                    marginBottom: "4px"
                                                },
                                                children: c.breed
                                            }, void 0, false, {
                                                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                                lineNumber: 513,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                style: {
                                                    color: "#666",
                                                    fontSize: "12px",
                                                    marginBottom: "4px"
                                                },
                                                children: c.info
                                            }, void 0, false, {
                                                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                                lineNumber: 516,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                style: {
                                                    fontSize: "10px",
                                                    color: "#999"
                                                },
                                                children: [
                                                    "ID: ",
                                                    c.id.substring(0, 20),
                                                    "..."
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                                lineNumber: 525,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                        lineNumber: 512,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, c.id, true, {
                                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                lineNumber: 487,
                                columnNumber: 15
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                        lineNumber: 479,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                lineNumber: 475,
                columnNumber: 9
            }, this),
            !loading && cats.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: "No cats available"
            }, void 0, false, {
                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                lineNumber: 535,
                columnNumber: 41
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
        lineNumber: 262,
        columnNumber: 5
    }, this);
}
_s(Home, "FTwnaX/3h9dUeVkk/Et80HwaPYw=");
_c = Home;
var _c;
__turbopack_context__.k.register(_c, "Home");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/node_modules/next/dist/compiled/react/cjs/react-jsx-dev-runtime.development.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * @license React
 * react-jsx-dev-runtime.development.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
"production" !== ("TURBOPACK compile-time value", "development") && function() {
    function getComponentNameFromType(type) {
        if (null == type) return null;
        if ("function" === typeof type) return type.$$typeof === REACT_CLIENT_REFERENCE ? null : type.displayName || type.name || null;
        if ("string" === typeof type) return type;
        switch(type){
            case REACT_FRAGMENT_TYPE:
                return "Fragment";
            case REACT_PROFILER_TYPE:
                return "Profiler";
            case REACT_STRICT_MODE_TYPE:
                return "StrictMode";
            case REACT_SUSPENSE_TYPE:
                return "Suspense";
            case REACT_SUSPENSE_LIST_TYPE:
                return "SuspenseList";
            case REACT_ACTIVITY_TYPE:
                return "Activity";
            case REACT_VIEW_TRANSITION_TYPE:
                return "ViewTransition";
        }
        if ("object" === typeof type) switch("number" === typeof type.tag && console.error("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), type.$$typeof){
            case REACT_PORTAL_TYPE:
                return "Portal";
            case REACT_CONTEXT_TYPE:
                return type.displayName || "Context";
            case REACT_CONSUMER_TYPE:
                return (type._context.displayName || "Context") + ".Consumer";
            case REACT_FORWARD_REF_TYPE:
                var innerType = type.render;
                type = type.displayName;
                type || (type = innerType.displayName || innerType.name || "", type = "" !== type ? "ForwardRef(" + type + ")" : "ForwardRef");
                return type;
            case REACT_MEMO_TYPE:
                return innerType = type.displayName || null, null !== innerType ? innerType : getComponentNameFromType(type.type) || "Memo";
            case REACT_LAZY_TYPE:
                innerType = type._payload;
                type = type._init;
                try {
                    return getComponentNameFromType(type(innerType));
                } catch (x) {}
        }
        return null;
    }
    function testStringCoercion(value) {
        return "" + value;
    }
    function checkKeyStringCoercion(value) {
        try {
            testStringCoercion(value);
            var JSCompiler_inline_result = !1;
        } catch (e) {
            JSCompiler_inline_result = !0;
        }
        if (JSCompiler_inline_result) {
            JSCompiler_inline_result = console;
            var JSCompiler_temp_const = JSCompiler_inline_result.error;
            var JSCompiler_inline_result$jscomp$0 = "function" === typeof Symbol && Symbol.toStringTag && value[Symbol.toStringTag] || value.constructor.name || "Object";
            JSCompiler_temp_const.call(JSCompiler_inline_result, "The provided key is an unsupported type %s. This value must be coerced to a string before using it here.", JSCompiler_inline_result$jscomp$0);
            return testStringCoercion(value);
        }
    }
    function getTaskName(type) {
        if (type === REACT_FRAGMENT_TYPE) return "<>";
        if ("object" === typeof type && null !== type && type.$$typeof === REACT_LAZY_TYPE) return "<...>";
        try {
            var name = getComponentNameFromType(type);
            return name ? "<" + name + ">" : "<...>";
        } catch (x) {
            return "<...>";
        }
    }
    function getOwner() {
        var dispatcher = ReactSharedInternals.A;
        return null === dispatcher ? null : dispatcher.getOwner();
    }
    function UnknownOwner() {
        return Error("react-stack-top-frame");
    }
    function hasValidKey(config) {
        if (hasOwnProperty.call(config, "key")) {
            var getter = Object.getOwnPropertyDescriptor(config, "key").get;
            if (getter && getter.isReactWarning) return !1;
        }
        return void 0 !== config.key;
    }
    function defineKeyPropWarningGetter(props, displayName) {
        function warnAboutAccessingKey() {
            specialPropKeyWarningShown || (specialPropKeyWarningShown = !0, console.error("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://react.dev/link/special-props)", displayName));
        }
        warnAboutAccessingKey.isReactWarning = !0;
        Object.defineProperty(props, "key", {
            get: warnAboutAccessingKey,
            configurable: !0
        });
    }
    function elementRefGetterWithDeprecationWarning() {
        var componentName = getComponentNameFromType(this.type);
        didWarnAboutElementRef[componentName] || (didWarnAboutElementRef[componentName] = !0, console.error("Accessing element.ref was removed in React 19. ref is now a regular prop. It will be removed from the JSX Element type in a future release."));
        componentName = this.props.ref;
        return void 0 !== componentName ? componentName : null;
    }
    function ReactElement(type, key, props, owner, debugStack, debugTask) {
        var refProp = props.ref;
        type = {
            $$typeof: REACT_ELEMENT_TYPE,
            type: type,
            key: key,
            props: props,
            _owner: owner
        };
        null !== (void 0 !== refProp ? refProp : null) ? Object.defineProperty(type, "ref", {
            enumerable: !1,
            get: elementRefGetterWithDeprecationWarning
        }) : Object.defineProperty(type, "ref", {
            enumerable: !1,
            value: null
        });
        type._store = {};
        Object.defineProperty(type._store, "validated", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: 0
        });
        Object.defineProperty(type, "_debugInfo", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: null
        });
        Object.defineProperty(type, "_debugStack", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: debugStack
        });
        Object.defineProperty(type, "_debugTask", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: debugTask
        });
        Object.freeze && (Object.freeze(type.props), Object.freeze(type));
        return type;
    }
    function jsxDEVImpl(type, config, maybeKey, isStaticChildren, debugStack, debugTask) {
        var children = config.children;
        if (void 0 !== children) if (isStaticChildren) if (isArrayImpl(children)) {
            for(isStaticChildren = 0; isStaticChildren < children.length; isStaticChildren++)validateChildKeys(children[isStaticChildren]);
            Object.freeze && Object.freeze(children);
        } else console.error("React.jsx: Static children should always be an array. You are likely explicitly calling React.jsxs or React.jsxDEV. Use the Babel transform instead.");
        else validateChildKeys(children);
        if (hasOwnProperty.call(config, "key")) {
            children = getComponentNameFromType(type);
            var keys = Object.keys(config).filter(function(k) {
                return "key" !== k;
            });
            isStaticChildren = 0 < keys.length ? "{key: someKey, " + keys.join(": ..., ") + ": ...}" : "{key: someKey}";
            didWarnAboutKeySpread[children + isStaticChildren] || (keys = 0 < keys.length ? "{" + keys.join(": ..., ") + ": ...}" : "{}", console.error('A props object containing a "key" prop is being spread into JSX:\n  let props = %s;\n  <%s {...props} />\nReact keys must be passed directly to JSX without using spread:\n  let props = %s;\n  <%s key={someKey} {...props} />', isStaticChildren, children, keys, children), didWarnAboutKeySpread[children + isStaticChildren] = !0);
        }
        children = null;
        void 0 !== maybeKey && (checkKeyStringCoercion(maybeKey), children = "" + maybeKey);
        hasValidKey(config) && (checkKeyStringCoercion(config.key), children = "" + config.key);
        if ("key" in config) {
            maybeKey = {};
            for(var propName in config)"key" !== propName && (maybeKey[propName] = config[propName]);
        } else maybeKey = config;
        children && defineKeyPropWarningGetter(maybeKey, "function" === typeof type ? type.displayName || type.name || "Unknown" : type);
        return ReactElement(type, children, maybeKey, getOwner(), debugStack, debugTask);
    }
    function validateChildKeys(node) {
        isValidElement(node) ? node._store && (node._store.validated = 1) : "object" === typeof node && null !== node && node.$$typeof === REACT_LAZY_TYPE && ("fulfilled" === node._payload.status ? isValidElement(node._payload.value) && node._payload.value._store && (node._payload.value._store.validated = 1) : node._store && (node._store.validated = 1));
    }
    function isValidElement(object) {
        return "object" === typeof object && null !== object && object.$$typeof === REACT_ELEMENT_TYPE;
    }
    var React = __turbopack_context__.r("[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"), REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element"), REACT_PORTAL_TYPE = Symbol.for("react.portal"), REACT_FRAGMENT_TYPE = Symbol.for("react.fragment"), REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode"), REACT_PROFILER_TYPE = Symbol.for("react.profiler"), REACT_CONSUMER_TYPE = Symbol.for("react.consumer"), REACT_CONTEXT_TYPE = Symbol.for("react.context"), REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref"), REACT_SUSPENSE_TYPE = Symbol.for("react.suspense"), REACT_SUSPENSE_LIST_TYPE = Symbol.for("react.suspense_list"), REACT_MEMO_TYPE = Symbol.for("react.memo"), REACT_LAZY_TYPE = Symbol.for("react.lazy"), REACT_ACTIVITY_TYPE = Symbol.for("react.activity"), REACT_VIEW_TRANSITION_TYPE = Symbol.for("react.view_transition"), REACT_CLIENT_REFERENCE = Symbol.for("react.client.reference"), ReactSharedInternals = React.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, hasOwnProperty = Object.prototype.hasOwnProperty, isArrayImpl = Array.isArray, createTask = console.createTask ? console.createTask : function() {
        return null;
    };
    React = {
        react_stack_bottom_frame: function(callStackForError) {
            return callStackForError();
        }
    };
    var specialPropKeyWarningShown;
    var didWarnAboutElementRef = {};
    var unknownOwnerDebugStack = React.react_stack_bottom_frame.bind(React, UnknownOwner)();
    var unknownOwnerDebugTask = createTask(getTaskName(UnknownOwner));
    var didWarnAboutKeySpread = {};
    exports.Fragment = REACT_FRAGMENT_TYPE;
    exports.jsxDEV = function(type, config, maybeKey, isStaticChildren) {
        var trackActualOwner = 1e4 > ReactSharedInternals.recentlyCreatedOwnerStacks++;
        if (trackActualOwner) {
            var previousStackTraceLimit = Error.stackTraceLimit;
            Error.stackTraceLimit = 10;
            var debugStackDEV = Error("react-stack-top-frame");
            Error.stackTraceLimit = previousStackTraceLimit;
        } else debugStackDEV = unknownOwnerDebugStack;
        return jsxDEVImpl(type, config, maybeKey, isStaticChildren, debugStackDEV, trackActualOwner ? createTask(getTaskName(type)) : unknownOwnerDebugTask);
    };
}();
}),
"[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use strict';
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
else {
    module.exports = __turbopack_context__.r("[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/node_modules/next/dist/compiled/react/cjs/react-jsx-dev-runtime.development.js [app-client] (ecmascript)");
}
}),
]);

//# sourceMappingURL=School_Tehnologije%20Integracije%20in%20Digitalizacij_cats_cats_fbba6e57._.js.map