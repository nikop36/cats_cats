globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/f13b8_next_dist_compiled_9e2cc3c2._.js",
      "static/chunks/f13b8_next_dist_shared_lib_78027dbc._.js",
      "static/chunks/f13b8_next_dist_client_3793e4d5._.js",
      "static/chunks/f13b8_next_dist_764e85ce._.js",
      "static/chunks/f13b8_next_app_655eb53d.js",
      "static/chunks/[next]_entry_page-loader_ts_d4a3072e._.js",
      "static/chunks/f13b8_react-dom_f63ac714._.js",
      "static/chunks/f13b8_a850c8ef._.js",
      "static/chunks/[root-of-the-server]__e0f9522d._.js",
      "static/chunks/School_Tehnologije Integracije in Digitalizacij_cats_cats_pages__app_2da965e7._.js",
      "static/chunks/cf9ee_Tehnologije Integracije in Digitalizacij_cats_cats_pages__app_2c8ec22b._.js"
    ],
    "/_error": [
      "static/chunks/f13b8_next_dist_compiled_9e2cc3c2._.js",
      "static/chunks/f13b8_next_dist_shared_lib_cfb2e476._.js",
      "static/chunks/f13b8_next_dist_client_3793e4d5._.js",
      "static/chunks/f13b8_next_dist_ac6d8565._.js",
      "static/chunks/f13b8_next_error_a1577e30.js",
      "static/chunks/[next]_entry_page-loader_ts_501a09c6._.js",
      "static/chunks/f13b8_react-dom_f63ac714._.js",
      "static/chunks/f13b8_a850c8ef._.js",
      "static/chunks/[root-of-the-server]__5677a870._.js",
      "static/chunks/School_Tehnologije Integracije in Digitalizacij_cats_cats_pages__error_2da965e7._.js",
      "static/chunks/cf9ee_Tehnologije Integracije in Digitalizacij_cats_cats_pages__error_56dd820f._.js"
    ]
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/f13b8_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_9d665b75._.js",
    "static/chunks/f13b8_next_dist_compiled_react-dom_224da474._.js",
    "static/chunks/f13b8_next_dist_compiled_react-server-dom-turbopack_c90b52af._.js",
    "static/chunks/f13b8_next_dist_compiled_next-devtools_index_37d188a4.js",
    "static/chunks/f13b8_next_dist_compiled_5847bf7c._.js",
    "static/chunks/f13b8_next_dist_client_1b72f04e._.js",
    "static/chunks/f13b8_next_dist_3a47afdd._.js",
    "static/chunks/f13b8_@swc_helpers_cjs_1b473e14._.js",
    "static/chunks/School_Tehnologije Integracije in Digitalizacij_cats_cats_a0ff3932._.js",
    "static/chunks/turbopack-School_Tehnologije Integracije in Digitalizacij_cats_cats_b085c02d._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];