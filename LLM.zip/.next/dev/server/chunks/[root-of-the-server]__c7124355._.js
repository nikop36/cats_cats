module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[externals]/process [external] (process, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("process", () => require("process"));

module.exports = mod;
}),
"[externals]/tls [external] (tls, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("tls", () => require("tls"));

module.exports = mod;
}),
"[externals]/os [external] (os, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("os", () => require("os"));

module.exports = mod;
}),
"[externals]/net [external] (net, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("net", () => require("net"));

module.exports = mod;
}),
"[externals]/events [external] (events, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}),
"[externals]/stream [external] (stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}),
"[externals]/zlib [external] (zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}),
"[externals]/http2 [external] (http2, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http2", () => require("http2"));

module.exports = mod;
}),
"[externals]/http [external] (http, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}),
"[externals]/url [external] (url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}),
"[externals]/dns [external] (dns, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("dns", () => require("dns"));

module.exports = mod;
}),
"[externals]/util [external] (util, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}),
"[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/api/cats/stream/route.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET,
    "dynamic",
    ()=>dynamic,
    "runtime",
    ()=>runtime
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/path [external] (path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f40$grpc$2f$proto$2d$loader$2f$build$2f$src$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/node_modules/@grpc/proto-loader/build/src/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f40$grpc$2f$grpc$2d$js$2f$build$2f$src$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/node_modules/@grpc/grpc-js/build/src/index.js [app-route] (ecmascript)");
;
;
;
const PROTO_PATH = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(process.cwd(), "proto", "cats.proto");
const packageDefinition = __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f40$grpc$2f$proto$2d$loader$2f$build$2f$src$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].loadSync(PROTO_PATH, {
    keepCase: true,
    longs: String,
    enums: String,
    defaults: true,
    oneofs: true
});
const proto = __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f40$grpc$2f$grpc$2d$js$2f$build$2f$src$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].loadPackageDefinition(packageDefinition).cats;
function getClient() {
    const grpcAddr = process.env.GRPC_SERVER_ADDR || "localhost:50051";
    return new proto.Cats(grpcAddr, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f40$grpc$2f$grpc$2d$js$2f$build$2f$src$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].credentials.createInsecure());
}
const dynamic = "force-dynamic";
const runtime = "nodejs";
async function GET(request) {
    const { searchParams } = new URL(request.url);
    const streamType = searchParams.get("type") || "feed";
    const breed = searchParams.get("breed") || "";
    console.log(`[Stream] Starting: type=${streamType}, breed=${breed}`);
    const encoder = new TextEncoder();
    let messagesSent = 0;
    let isClosed = false;
    const readableStream = new ReadableStream({
        async start (controller) {
            const client = getClient();
            let grpcStream;
            try {
                console.log(`[Stream] Creating ${streamType} stream`);
                switch(streamType){
                    case "breed":
                        if (!breed) throw new Error("Breed parameter required");
                        console.log(`[Stream] StreamCatsByBreed(${breed})`);
                        grpcStream = client.StreamCatsByBreed({
                            breed: breed.trim()
                        });
                        break;
                    case "new":
                        console.log(`[Stream] StreamNewCats()`);
                        grpcStream = client.StreamNewCats({});
                        break;
                    default:
                        console.log(`[Stream] StreamCatFeed()`);
                        grpcStream = client.StreamCatFeed({});
                }
                controller.enqueue(encoder.encode(": Stream connected\n\n"));
                grpcStream.on("data", (data)=>{
                    if (isClosed) return;
                    try {
                        messagesSent++;
                        const json = JSON.stringify(data);
                        console.log(`[Stream] Message ${messagesSent}`);
                        controller.enqueue(encoder.encode(`data: ${json}\n\n`));
                    } catch (err) {
                        console.error(`[Stream] Data error:`, err.message);
                    }
                });
                grpcStream.on("error", (err)=>{
                    if (isClosed) return;
                    console.error(`[Stream] gRPC error:`, err.message);
                    isClosed = true;
                    try {
                        controller.enqueue(encoder.encode(`data: ${JSON.stringify({
                            error: err.message
                        })}\n\n`));
                        controller.close();
                    } catch (e) {
                        console.error(`[Stream] Error close:`, e.message);
                    }
                });
                grpcStream.on("end", ()=>{
                    if (isClosed) return;
                    console.log(`[Stream] Ended (${messagesSent} msgs)`);
                    isClosed = true;
                    try {
                        controller.close();
                    } catch (e) {
                        console.error(`[Stream] Error closing controller:`, e.message);
                    }
                });
                // Handle client disconnect
                request.signal?.addEventListener("abort", ()=>{
                    if (isClosed) return;
                    console.log(`[Stream] Client disconnected`);
                    isClosed = true;
                    try {
                        grpcStream?.cancel?.();
                        controller.close();
                    } catch (e) {
                        console.error(`[Stream] Error on abort:`, e.message);
                    }
                });
            } catch (err) {
                console.error(`[Stream] Setup error:`, err.message);
                isClosed = true;
                try {
                    controller.enqueue(encoder.encode(`data: ${JSON.stringify({
                        error: err.message
                    })}\n\n`));
                    controller.close();
                } catch (e) {
                    console.error(`[Stream] Error closing on setup error:`, e.message);
                }
            }
        }
    });
    return new Response(readableStream, {
        headers: {
            "Content-Type": "text/event-stream; charset=utf-8",
            "Cache-Control": "no-cache",
            Connection: "keep-alive",
            "X-Accel-Buffering": "no"
        }
    });
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__c7124355._.js.map