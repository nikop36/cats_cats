module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Home
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
function Home() {
    const [cats, setCats] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [streaming, setStreaming] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [streamType, setStreamType] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("feed");
    const [breedFilter, setBreedFilter] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [streamStatus, setStreamStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [messageCount, setMessageCount] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0);
    const eventSourceRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const messageCountRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(0);
    // Fetch initial cats
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        let mounted = true;
        setLoading(true);
        fetch("/api/cats").then((res)=>{
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            return res.json();
        }).then((data)=>{
            if (!mounted) return;
            setCats(Array.isArray(data.cats) ? data.cats : []);
            setError(null);
        }).catch((err)=>{
            if (!mounted) return;
            console.error("[Frontend] Initial fetch error:", err);
            setError(err.message || "Failed to fetch");
            setCats([]);
        }).finally(()=>{
            if (!mounted) return;
            setLoading(false);
        });
        return ()=>{
            mounted = false;
        };
    }, []);
    // Handle streaming
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        // If breed stream is selected but no breed entered, don't start streaming
        if (streaming && streamType === "breed" && !breedFilter.trim()) {
            console.log("[Frontend] Breed filter empty, not starting stream");
            setStreamStatus("⏳ Enter a breed name to start streaming");
            return;
        }
        if (!streaming) {
            if (eventSourceRef.current) {
                console.log("[Frontend] Closing stream");
                eventSourceRef.current.close();
                eventSourceRef.current = null;
            }
            setStreamStatus("");
            messageCountRef.current = 0;
            setMessageCount(0);
            return;
        }
        let mounted = true;
        // Build URL
        const url = new URL("/api/cats/stream", window.location.origin);
        url.searchParams.set("type", streamType);
        if (streamType === "breed") {
            url.searchParams.set("breed", breedFilter.trim());
        }
        const streamUrl = url.toString();
        console.log(`[Frontend] Opening stream: ${streamUrl}`);
        setStreamStatus(`🔄 Connecting to ${streamType}... `);
        messageCountRef.current = 0;
        setMessageCount(0);
        try {
            const es = new EventSource(streamUrl);
            eventSourceRef.current = es;
            es.addEventListener("message", (event)=>{
                if (!mounted) return;
                try {
                    const data = JSON.parse(event.data);
                    console.log(`[Frontend] Received:`, data);
                    if (data.error) {
                        console.error("[Frontend] Server error:", data.error);
                        setError(`Stream error: ${data.error}`);
                        setStreaming(false);
                        return;
                    }
                    // Extract cat from message
                    const cat = data.cat || data;
                    if (!cat.id) {
                        console.warn("[Frontend] Invalid cat data:", data);
                        return;
                    }
                    console.log(`[Frontend] Got cat: ${cat.breed}`);
                    setCats((prevCats)=>{
                        const exists = prevCats.some((c)=>c.id === cat.id);
                        if (exists) {
                            console.log(`[Frontend] Cat already exists: ${cat.id}`);
                            return prevCats;
                        }
                        return [
                            cat,
                            ...prevCats
                        ];
                    });
                    messageCountRef.current++;
                    setMessageCount(messageCountRef.current);
                    setStreamStatus(`✅ Streaming ${streamType}${streamType === "breed" ? ` (${breedFilter})` : ""} - ${messageCountRef.current} messages`);
                } catch (err) {
                    console.error("[Frontend] Parse error:", err, "Raw data:", event.data);
                }
            });
            es.onerror = (event)=>{
                console.error("[Frontend] EventSource onerror.  ReadyState:", es.readyState, "Event:", event);
                if (mounted) {
                    // ReadyState: 0=connecting, 1=open, 2=closed
                    if (es.readyState === EventSource.CLOSED) {
                        console.log("[Frontend] Stream closed by server");
                        setStreamStatus("⏹️ Stream closed (server ended)");
                    } else {
                        console.error("[Frontend] Stream connection lost");
                        setError(`Stream connection lost (readyState: ${es.readyState})`);
                        setStreaming(false);
                    }
                }
                es.close();
            };
            console.log("[Frontend] Stream opened successfully");
        } catch (err) {
            console.error("[Frontend] Stream setup error:", err);
            if (mounted) {
                setError(`Stream error: ${String(err)}`);
                setStreaming(false);
            }
        }
        return ()=>{
            mounted = false;
            if (eventSourceRef.current) {
                console.log("[Frontend] Cleanup: closing stream");
                eventSourceRef.current.close();
                eventSourceRef.current = null;
            }
        };
    }, [
        streaming,
        streamType,
        breedFilter
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        style: {
            padding: "20px",
            fontFamily: "sans-serif"
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                children: "🐱 Cat Feed with gRPC Streaming"
            }, void 0, false, {
                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                lineNumber: 193,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    marginBottom: "20px",
                    padding: "15px",
                    backgroundColor: "gray",
                    borderRadius: "8px"
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            marginBottom: "10px"
                        },
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "checkbox",
                                    checked: streaming,
                                    onChange: (e)=>{
                                        setStreaming(e.target.checked);
                                        if (!e.target.checked) {
                                            setStreamType("feed");
                                            setBreedFilter("");
                                        }
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                    lineNumber: 206,
                                    columnNumber: 13
                                }, this),
                                " Enable Real-time Streaming"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                            lineNumber: 205,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                        lineNumber: 204,
                        columnNumber: 9
                    }, this),
                    streaming && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    marginBottom: "10px"
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        children: "Stream Type: "
                                    }, void 0, false, {
                                        fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                        lineNumber: 224,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                        value: streamType,
                                        onChange: (e)=>{
                                            setStreamType(e.target.value);
                                            if (e.target.value !== "breed") {
                                                setBreedFilter("");
                                            }
                                        },
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "feed",
                                                children: "📡 StreamCatFeed (All)"
                                            }, void 0, false, {
                                                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                                lineNumber: 234,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "new",
                                                children: "🆕 StreamNewCats (New Only)"
                                            }, void 0, false, {
                                                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                                lineNumber: 235,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "breed",
                                                children: "🐱 StreamCatsByBreed (Filter)"
                                            }, void 0, false, {
                                                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                                lineNumber: 236,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                        lineNumber: 225,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                lineNumber: 223,
                                columnNumber: 13
                            }, this),
                            streamType === "breed" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        children: "Breed Filter: "
                                    }, void 0, false, {
                                        fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                        lineNumber: 242,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "text",
                                        placeholder: "e.g., Tabby, Siamese, Maine",
                                        value: breedFilter,
                                        onChange: (e)=>setBreedFilter(e.target.value),
                                        style: {
                                            padding: "5px",
                                            marginLeft: "10px"
                                        },
                                        autoFocus: true
                                    }, void 0, false, {
                                        fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                        lineNumber: 243,
                                        columnNumber: 17
                                    }, this),
                                    breedFilter && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                                        style: {
                                            marginLeft: "10px",
                                            color: "#666"
                                        },
                                        children: [
                                            '✅ Filter active: "',
                                            breedFilter,
                                            '"'
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                        lineNumber: 252,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                lineNumber: 241,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true)
                ]
            }, void 0, true, {
                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                lineNumber: 196,
                columnNumber: 7
            }, this),
            loading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: "⏳ Loading..."
            }, void 0, false, {
                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                lineNumber: 263,
                columnNumber: 19
            }, this),
            streamStatus && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    color: streamStatus.includes("⏳") ? "orange" : streamStatus.includes("❌") ? "red" : "green",
                    marginBottom: "10px",
                    padding: "10px",
                    backgroundColor: "gray",
                    borderRadius: "4px"
                },
                children: streamStatus
            }, void 0, false, {
                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                lineNumber: 265,
                columnNumber: 9
            }, this),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    color: "red",
                    marginBottom: "10px",
                    padding: "10px",
                    backgroundColor: "gray",
                    borderRadius: "4px"
                },
                children: [
                    "❌ ",
                    error
                ]
            }, void 0, true, {
                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                lineNumber: 282,
                columnNumber: 9
            }, this),
            !loading && cats.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        children: [
                            cats.length,
                            " Cats ",
                            streamType === "breed" && `(${breedFilter})`
                        ]
                    }, void 0, true, {
                        fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                        lineNumber: 298,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            display: "grid",
                            gridTemplateColumns: "repeat(auto-fill, minmax(250px, 1fr))",
                            gap: "20px"
                        },
                        children: cats.map((c)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    border: "1px solid #ddd",
                                    borderRadius: "8px",
                                    padding: "12px",
                                    boxShadow: "0 2px 4px rgba(0,0,0,0.1)"
                                },
                                children: [
                                    c.url && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                        src: c.url,
                                        alt: c.breed,
                                        width: "100%",
                                        style: {
                                            height: "200px",
                                            objectFit: "cover",
                                            borderRadius: "4px",
                                            marginBottom: "8px"
                                        },
                                        onError: (e)=>{
                                            e.target.style.display = "none";
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                        lineNumber: 319,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        style: {
                                            fontSize: "14px"
                                        },
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                style: {
                                                    fontWeight: "bold",
                                                    marginBottom: "4px"
                                                },
                                                children: c.breed
                                            }, void 0, false, {
                                                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                                lineNumber: 335,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                style: {
                                                    color: "#666",
                                                    fontSize: "12px",
                                                    marginBottom: "4px"
                                                },
                                                children: c.info
                                            }, void 0, false, {
                                                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                                lineNumber: 338,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                style: {
                                                    fontSize: "10px",
                                                    color: "#999"
                                                },
                                                children: [
                                                    "ID: ",
                                                    c.id.substring(0, 20),
                                                    "..."
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                                lineNumber: 347,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                        lineNumber: 334,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, c.id, true, {
                                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                                lineNumber: 309,
                                columnNumber: 15
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                        lineNumber: 301,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                lineNumber: 297,
                columnNumber: 9
            }, this),
            !loading && cats.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$School$2f$Tehnologije__Integracije__in__Digitalizacij$2f$cats_cats$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: "No cats available"
            }, void 0, false, {
                fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
                lineNumber: 357,
                columnNumber: 41
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx",
        lineNumber: 192,
        columnNumber: 5
    }, this);
}
}),
"[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/node_modules/next/dist/server/route-modules/app-page/module.compiled.js [app-ssr] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
else {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    else {
        if ("TURBOPACK compile-time truthy", 1) {
            if ("TURBOPACK compile-time truthy", 1) {
                module.exports = __turbopack_context__.r("[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)");
            } else //TURBOPACK unreachable
            ;
        } else //TURBOPACK unreachable
        ;
    }
} //# sourceMappingURL=module.compiled.js.map
}),
"[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

module.exports = __turbopack_context__.r("[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/node_modules/next/dist/server/route-modules/app-page/module.compiled.js [app-ssr] (ecmascript)").vendored['react-ssr'].ReactJsxDevRuntime; //# sourceMappingURL=react-jsx-dev-runtime.js.map
}),
"[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

module.exports = __turbopack_context__.r("[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/node_modules/next/dist/server/route-modules/app-page/module.compiled.js [app-ssr] (ecmascript)").vendored['react-ssr'].React; //# sourceMappingURL=react.js.map
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__2440e114._.js.map