module.exports = [
"[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/favicon.ico.mjs { IMAGE => \"[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/favicon.ico.mjs { IMAGE => \"[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/layout.tsx [app-rsc] (ecmascript)"));
}),
"[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {

}),
"[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/page.tsx [app-rsc] (ecmascript)"));
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__65680791._.js.map