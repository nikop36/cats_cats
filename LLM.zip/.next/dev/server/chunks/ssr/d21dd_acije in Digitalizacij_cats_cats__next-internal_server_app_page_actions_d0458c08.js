module.exports = [
"[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=d21dd_acije%20in%20Digitalizacij_cats_cats__next-internal_server_app_page_actions_d0458c08.js.map