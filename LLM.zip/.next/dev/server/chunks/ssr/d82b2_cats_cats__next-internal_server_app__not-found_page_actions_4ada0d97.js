module.exports = [
"[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/.next-internal/server/app/_not-found/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=d82b2_cats_cats__next-internal_server_app__not-found_page_actions_4ada0d97.js.map