module.exports = [
"[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/.next-internal/server/app/api/cats/stream/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=d82b2_cats_cats__next-internal_server_app_api_cats_stream_route_actions_9bd8e4b7.js.map