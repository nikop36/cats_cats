var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/cats/route.js")
R.c("server/chunks/f13b8_next_b794bb2a._.js")
R.c("server/chunks/f13b8_protobufjs_178b8768._.js")
R.c("server/chunks/f13b8_@grpc_grpc-js_06c135f9._.js")
R.c("server/chunks/f13b8_d207bad9._.js")
R.c("server/chunks/[root-of-the-server]__3000df1f._.js")
R.c("server/chunks/d82b2_cats_cats__next-internal_server_app_api_cats_route_actions_b7d8a288.js")
R.m("[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/api/cats/route.js [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/app/api/cats/route.js [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
