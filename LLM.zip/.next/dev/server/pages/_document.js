var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/f13b8_d4144726._.js")
R.c("server/chunks/ssr/[root-of-the-server]__e6a4d965._.js")
R.m("[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/node_modules/next/document.js [ssr] (ecmascript)")
module.exports=R.m("[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/node_modules/next/document.js [ssr] (ecmascript)").exports
