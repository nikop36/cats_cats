var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_error.js")
R.c("server/chunks/ssr/f13b8_93e075d9._.js")
R.c("server/chunks/ssr/[externals]_next_dist_shared_lib_no-fallback-error_external_59b92b38.js")
R.c("server/chunks/ssr/f13b8_d4144726._.js")
R.c("server/chunks/ssr/[root-of-the-server]__e6a4d965._.js")
R.c("server/chunks/ssr/f13b8_next_5cb6ab74._.js")
R.m("[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/node_modules/next/error.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/node_modules/next/document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/node_modules/next/app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)")
module.exports=R.m("[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/node_modules/next/error.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/node_modules/next/document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/School/Tehnologije Integracije in Digitalizacij/cats_cats/node_modules/next/app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)").exports
